********************
List of Deliverables
********************

Report in .pdf format.

Release mode executable for both:
5x5x5 FIS Application.
An attempt at a generalized NxNxM FIS (left at 7x7x13).

************************
Application Instructions
************************

The applications are both a console window and an SFML render window.
User instructions are outputted to the console window initially.
***NOTE***: The console must be focused to work.

Console must be focused when setting up or restting the FIS.
The SFML render window should be focused when the FIS is running.
***NOTE***: The SFML window may crash sometimes while waiting for console input.