Menu controls:
WASD to navigate buttons.
Space to start game (when on start button).

Game controls:
WASD to move.
Space to fire photon.
LMB to fire cannon projectile.

Known issues:
	Networking issues:
	Score isn't synced properly.
	Every second client receives garbage messages.
	If a client is stopped it's send buffer will fill and the server will crash.

	Game issues:
	Sound is not implemented, sound buttons do nothing.
	Sometimes collision response doesn't occur or occurs twice. (things don't take damage or take double damage)